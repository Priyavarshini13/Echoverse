import streamlit as st
import re
import random

def show_tone_selection_page():
    """Display tone selection page"""
    
    # Custom CSS for tone selection page
    st.markdown("""
    <style>
    .tone-page-container {
        background: linear-gradient(135deg, #fd79a8 0%, #e84393 25%, #6c5ce7 50%, #74b9ff 75%, #00cec9 100%);
        background-size: 400% 400%;
        animation: gradientShift 12s ease infinite;
        min-height: 100vh;
        padding: 2rem;
    }
    
    .tone-selection-card {
        background: rgba(255, 255, 255, 0.95);
        border-radius: 20px;
        padding: 2rem;
        backdrop-filter: blur(10px);
        box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        margin-bottom: 2rem;
    }
    
    .page-title {
        text-align: center;
        color: white;
        font-size: 2.5rem;
        margin-bottom: 2rem;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    }
    
    .tone-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 15px;
        padding: 2rem;
        text-align: center;
        margin: 1rem 0;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        cursor: pointer;
        border: none;
    }
    
    .tone-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px rgba(0,0,0,0.3);
    }
    
    .tone-emoji {
        font-size: 3rem;
        margin-bottom: 1rem;
    }
    
    .tone-title {
        font-size: 1.5rem;
        font-weight: bold;
        margin-bottom: 0.5rem;
    }
    
    .tone-description {
        font-size: 1rem;
        opacity: 0.9;
    }
    
    @keyframes gradientShift {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }
    </style>
    """, unsafe_allow_html=True)
    
    st.markdown('<div class="tone-page-container">', unsafe_allow_html=True)
    
    st.markdown('<div class="page-title">🎭 Choose Your Tone</div>', unsafe_allow_html=True)
    
    with st.container():
        st.markdown('<div class="tone-selection-card">', unsafe_allow_html=True)
        
        # Back button
        if st.button("⬅️ Back", key="back_from_tone"):
            if st.session_state.get('input_method') == 'text':
                st.session_state.current_page = 'text_input'
            elif st.session_state.get('input_method') == 'file':
                st.session_state.current_page = 'file_input'
            else:
                st.session_state.current_page = 'dashboard'
            st.rerun()
        
        # Show original text preview
        if 'original_text' in st.session_state:
            st.markdown("### 📖 Your Content Preview")
            preview_text = st.session_state.original_text[:300] + "..." if len(st.session_state.original_text) > 300 else st.session_state.original_text
            st.text_area("Content Preview:", preview_text, height=150, disabled=True, key="preview_content", help="Preview of your content")
        
        st.markdown("### 🎨 Select the tone for your audiobook:")
        
        # Tone selection buttons
        col1, col2, col3 = st.columns(3)
        
        tones = {
            "Neutral": {
                "emoji": "😐",
                "description": "Clear, balanced, and professional narration",
                "gradient": "linear-gradient(135deg, #74b9ff, #0984e3)"
            },
            "Suspenseful": {
                "emoji": "😰", 
                "description": "Thrilling, mysterious, and engaging tone",
                "gradient": "linear-gradient(135deg, #fd79a8, #e84393)"
            },
            "Inspiring": {
                "emoji": "✨",
                "description": "Motivational, uplifting, and energizing tone",
                "gradient": "linear-gradient(135deg, #00cec9, #6c5ce7)"
            }
        }
        
        with col1:
            st.markdown(f"""
            <div class="tone-card" style="background: {tones['Neutral']['gradient']};">
                <div class="tone-emoji">{tones['Neutral']['emoji']}</div>
                <div class="tone-title">Neutral</div>
                <div class="tone-description">{tones['Neutral']['description']}</div>
            </div>
            """, unsafe_allow_html=True)
            
            if st.button("Choose Neutral", key="neutral_tone", use_container_width=True):
                st.session_state.selected_tone = "Neutral"
                process_tone_selection()
        
        with col2:
            st.markdown(f"""
            <div class="tone-card" style="background: {tones['Suspenseful']['gradient']};">
                <div class="tone-emoji">{tones['Suspenseful']['emoji']}</div>
                <div class="tone-title">Suspenseful</div>
                <div class="tone-description">{tones['Suspenseful']['description']}</div>
            </div>
            """, unsafe_allow_html=True)
            
            if st.button("Choose Suspenseful", key="suspenseful_tone", use_container_width=True):
                st.session_state.selected_tone = "Suspenseful"
                process_tone_selection()
        
        with col3:
            st.markdown(f"""
            <div class="tone-card" style="background: {tones['Inspiring']['gradient']};">
                <div class="tone-emoji">{tones['Inspiring']['emoji']}</div>
                <div class="tone-title">Inspiring</div>
                <div class="tone-description">{tones['Inspiring']['description']}</div>
            </div>
            """, unsafe_allow_html=True)
            
            if st.button("Choose Inspiring", key="inspiring_tone", use_container_width=True):
                st.session_state.selected_tone = "Inspiring"
                process_tone_selection()
        
        st.markdown('</div>', unsafe_allow_html=True)
    
    st.markdown('</div>', unsafe_allow_html=True)

def process_tone_selection():
    """Process the selected tone and rewrite text"""
    try:
        with st.spinner(f"Rewriting your text in {st.session_state.selected_tone} tone..."):
            # Simple rule-based text rewriting
            original_text = st.session_state.original_text
            tone = st.session_state.selected_tone
            
            sentences = re.split(r'[.!?]+', original_text)
            rewritten_sentences = []
            
            for sentence in sentences:
                if not sentence.strip():
                    continue
                    
                if tone == "Suspenseful":
                    # Add suspenseful elements
                    sentence = sentence.replace(" said ", " whispered ")
                    sentence = sentence.replace(" walked ", " crept ")
                    sentence = sentence.replace(" looked ", " peered ")
                    if len(sentence.split()) > 5:
                        sentence = f"Suddenly, {sentence.strip()}"
                    sentence += "..."
                    
                elif tone == "Inspiring":
                    # Add motivational elements
                    sentence = sentence.replace(" can't ", " can ")
                    sentence = sentence.replace(" impossible ", " achievable ")
                    sentence = sentence.replace(" difficult ", " rewarding ")
                    if len(sentence.split()) > 3:
                        starters = ["Remarkably, ", "Incredibly, ", "With passion, ", "Courageously, "]
                        sentence = random.choice(starters) + sentence.strip()
                    sentence += "!"
                    
                else:  # Neutral
                    sentence = sentence.replace("...", ".").replace("!!!", "!")
                    sentence = re.sub(r'\s+', ' ', sentence)
                    sentence = sentence.strip() + "."
                
                rewritten_sentences.append(sentence)
            
            st.session_state.rewritten_text = " ".join(rewritten_sentences)
        
        st.success(f"✅ Text successfully rewritten in {st.session_state.selected_tone} tone!")
        st.session_state.current_page = 'voice_selection'
        st.rerun()
        
    except Exception as e:
        st.error(f"Error processing tone: {str(e)}")
        st.session_state.rewritten_text = st.session_state.original_text