import streamlit as st

def show_login_page():
    """Display login/sign-in page"""
    
    # Custom CSS for login page
    st.markdown("""
    <style>
    .login-container {
        background: linear-gradient(45deg, #ff6b6b, #4ecdc4, #45b7d1, #96ceb4, #feca57, #ff9ff3);
        background-size: 300% 300%;
        animation: gradientShift 8s ease infinite;
        min-height: 100vh;
        padding: 2rem;
    }
    
    .login-card {
        background: rgba(255, 255, 255, 0.95);
        border-radius: 20px;
        padding: 3rem;
        box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        backdrop-filter: blur(10px);
        max-width: 500px;
        margin: 0 auto;
        text-align: center;
    }
    
    .login-title {
        font-size: 2.5rem;
        color: #333;
        margin-bottom: 1rem;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
    }
    
    .login-subtitle {
        font-size: 1.2rem;
        color: #666;
        margin-bottom: 2rem;
    }
    
    .language-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
        gap: 15px;
        margin: 2rem 0;
    }
    
    .language-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 15px;
        border-radius: 15px;
        text-align: center;
        transition: transform 0.3s ease;
        cursor: pointer;
        border: none;
        font-size: 1rem;
        font-weight: bold;
    }
    
    .language-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0,0,0,0.2);
    }
    
    .welcome-features {
        background: rgba(255,255,255,0.1);
        border-radius: 15px;
        padding: 2rem;
        margin: 2rem 0;
    }
    
    .feature-item {
        display: flex;
        align-items: center;
        margin: 1rem 0;
        font-size: 1.1rem;
        color: #333;
    }
    
    .feature-icon {
        font-size: 1.5rem;
        margin-right: 15px;
        background: linear-gradient(45deg, #ff6b6b, #4ecdc4);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    
    @keyframes gradientShift {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }
    </style>
    """, unsafe_allow_html=True)
    
    st.markdown('<div class="login-container">', unsafe_allow_html=True)
    
    with st.container():
        st.markdown("""
        <div class="login-card">
            <div class="login-title">🎧 Welcome to EchoVerse</div>
            <div class="login-subtitle">Transform your text into amazing audiobooks!</div>
            
            <div class="welcome-features">
                <div class="feature-item">
                    <span class="feature-icon">🌍</span>
                    <span>Multiple Languages Supported</span>
                </div>
                <div class="feature-item">
                    <span class="feature-icon">🎭</span>
                    <span>Choose Your Tone (Neutral, Suspenseful, Inspiring)</span>
                </div>
                <div class="feature-item">
                    <span class="feature-icon">🗣️</span>
                    <span>Natural Voice Selection</span>
                </div>
                <div class="feature-item">
                    <span class="feature-icon">📱</span>
                    <span>Easy to Use - Perfect for Everyone</span>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        # Language selection for login
        st.markdown("### 🌍 Choose Your Language")
        st.markdown("*Select your preferred language to continue*")
        
        # Create language selection grid
        languages = {
            'en': {'name': 'English', 'flag': '🇺🇸'},
            'hi': {'name': 'हिंदी', 'flag': '🇮🇳'},
            'ta': {'name': 'தமிழ்', 'flag': '🇮🇳'},
            'es': {'name': 'Español', 'flag': '🇪🇸'},
            'fr': {'name': 'Français', 'flag': '🇫🇷'},
            'de': {'name': 'Deutsch', 'flag': '🇩🇪'},
            'ja': {'name': '日本語', 'flag': '🇯🇵'},
            'ko': {'name': '한국어', 'flag': '🇰🇷'}
        }
        
        cols = st.columns(4)
        for idx, (lang_code, lang_info) in enumerate(languages.items()):
            with cols[idx % 4]:
                if st.button(
                    f"{lang_info['flag']} {lang_info['name']}", 
                    key=f"lang_{lang_code}",
                    use_container_width=True
                ):
                    st.session_state.user_language = lang_code
                    st.session_state.current_page = 'dashboard'
                    st.success(f"Welcome! Language set to {lang_info['name']}")
                    st.rerun()
        
        # Guest login option
        st.markdown("---")
        if st.button("🚀 Continue as Guest (English)", use_container_width=True, type="primary"):
            st.session_state.user_language = 'en'
            st.session_state.current_page = 'dashboard'
            st.success("Welcome! Starting in English mode.")
            st.rerun()
    
    st.markdown('</div>', unsafe_allow_html=True)