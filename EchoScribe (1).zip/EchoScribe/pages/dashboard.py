import streamlit as st

def show_dashboard():
    """Display main dashboard with navigation to different features"""
    
    # Custom CSS for dashboard
    st.markdown("""
    <style>
    .dashboard-container {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 25%, #f093fb 50%, #f5576c 75%, #4facfe 100%);
        background-size: 300% 300%;
        animation: gradientShift 10s ease infinite;
        min-height: 100vh;
        padding: 2rem;
    }
    
    .dashboard-header {
        text-align: center;
        margin-bottom: 3rem;
        color: white;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    }
    
    .dashboard-title {
        font-size: 3rem;
        margin-bottom: 0.5rem;
    }
    
    .dashboard-subtitle {
        font-size: 1.2rem;
        opacity: 0.9;
    }
    
    .feature-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 2rem;
        margin: 2rem 0;
    }
    
    .feature-card {
        background: rgba(255, 255, 255, 0.95);
        border-radius: 20px;
        padding: 2rem;
        text-align: center;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255,255,255,0.2);
    }
    
    .feature-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 20px 40px rgba(0,0,0,0.2);
    }
    
    .feature-icon {
        font-size: 3rem;
        margin-bottom: 1rem;
        background: linear-gradient(45deg, #ff6b6b, #4ecdc4);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    
    .feature-title {
        font-size: 1.5rem;
        color: #333;
        margin-bottom: 1rem;
        font-weight: bold;
    }
    
    .feature-description {
        color: #666;
        margin-bottom: 2rem;
        line-height: 1.6;
    }
    
    @keyframes gradientShift {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }
    </style>
    """, unsafe_allow_html=True)
    
    st.markdown('<div class="dashboard-container">', unsafe_allow_html=True)
    
    # Header
    st.markdown("""
    <div class="dashboard-header">
        <div class="dashboard-title">🎧 EchoVerse Dashboard</div>
        <div class="dashboard-subtitle">Choose how you want to create your audiobook</div>
    </div>
    """, unsafe_allow_html=True)
    
    # User info
    user_language = st.session_state.get('user_language', 'en')
    language_names = {
        'en': 'English', 'hi': 'Hindi', 'ta': 'Tamil', 'es': 'Spanish',
        'fr': 'French', 'de': 'German', 'ja': 'Japanese', 'ko': 'Korean'
    }
    
    st.sidebar.markdown(f"### Welcome!")
    st.sidebar.markdown(f"**Language:** {language_names.get(user_language, 'English')}")
    
    if st.sidebar.button("🔄 Change Language"):
        st.session_state.current_page = 'login'
        st.rerun()
    
    if st.sidebar.button("🚪 Logout"):
        for key in list(st.session_state.keys()):
            del st.session_state[key]
        st.session_state.show_splash = True
        st.rerun()
    
    # Feature cards
    col1, col2 = st.columns(2)
    
    with col1:
        with st.container():
            st.markdown("""
            <div class="feature-card">
                <div class="feature-icon">📝</div>
                <div class="feature-title">Text Input</div>
                <div class="feature-description">Type or paste your text directly and convert it to an audiobook with your chosen tone and voice.</div>
            </div>
            """, unsafe_allow_html=True)
            
            if st.button("Start with Text", key="text_input", use_container_width=True, type="primary"):
                st.session_state.current_page = 'text_input'
                st.session_state.input_method = 'text'
                st.rerun()
    
    with col2:
        with st.container():
            st.markdown("""
            <div class="feature-card">
                <div class="feature-icon">📄</div>
                <div class="feature-title">File Upload</div>
                <div class="feature-description">Upload PDF, Word documents, or text files to automatically extract and convert content to audiobook.</div>
            </div>
            """, unsafe_allow_html=True)
            
            if st.button("Upload Files", key="file_input", use_container_width=True, type="primary"):
                st.session_state.current_page = 'file_input'
                st.session_state.input_method = 'file'
                st.rerun()
    
    col3, col4 = st.columns(2)
    
    with col3:
        with st.container():
            st.markdown("""
            <div class="feature-card">
                <div class="feature-icon">🎤</div>
                <div class="feature-title">Voice Recording</div>
                <div class="feature-description">Record your voice directly and convert speech to text, then transform into an audiobook.</div>
            </div>
            """, unsafe_allow_html=True)
            
            if st.button("Record Voice", key="voice_input", use_container_width=True, type="primary"):
                st.session_state.current_page = 'voice_input'
                st.session_state.input_method = 'voice'
                st.rerun()
    
    with col4:
        with st.container():
            st.markdown("""
            <div class="feature-card">
                <div class="feature-icon">🎨</div>
                <div class="feature-title">Tone Studio</div>
                <div class="feature-description">Advanced tone and voice customization options for professional audiobook creation.</div>
            </div>
            """, unsafe_allow_html=True)
            
            if st.button("Tone Studio", key="tone_studio", use_container_width=True, type="primary"):
                st.session_state.current_page = 'tone_studio'
                st.rerun()
    
    # Recent projects section
    st.markdown("---")
    st.markdown("### 📚 Recent Projects")
    
    if 'recent_projects' not in st.session_state:
        st.session_state.recent_projects = []
    
    if st.session_state.recent_projects:
        for project in st.session_state.recent_projects[-3:]:  # Show last 3
            st.markdown(f"🎧 **{project['title']}** - {project['date']}")
    else:
        st.info("No recent projects. Create your first audiobook!")
    
    st.markdown('</div>', unsafe_allow_html=True)