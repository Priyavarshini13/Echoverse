import streamlit as st
import os
from PyPDF2 import PdfReader
from docx import Document

def extract_text_from_file(uploaded_file):
    """Extract text from uploaded files"""
    try:
        if uploaded_file.type == "application/pdf":
            # PDF extraction
            pdf_reader = PdfReader(uploaded_file)
            text = ""
            for page in pdf_reader.pages:
                text += page.extract_text() + "\n"
            return text.strip()
        
        elif uploaded_file.type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
            # DOCX extraction
            doc = Document(uploaded_file)
            text = ""
            for paragraph in doc.paragraphs:
                text += paragraph.text + "\n"
            return text.strip()
        
        elif uploaded_file.type == "text/plain":
            # TXT extraction
            text = uploaded_file.read().decode('utf-8')
            return text.strip()
        
        else:
            st.error(f"Unsupported file type: {uploaded_file.type}")
            return None
            
    except Exception as e:
        st.error(f"Error extracting text from {uploaded_file.name}: {str(e)}")
        return None

def show_text_input_page():
    """Display enhanced text input page with multiple format support"""
    
    # Custom CSS for text input page with larger fonts
    st.markdown("""
    <style>
    .text-page-container {
        background: linear-gradient(135deg, #74b9ff 0%, #0984e3 50%, #00cec9 100%);
        background-size: 300% 300%;
        animation: gradientShift 8s ease infinite;
        min-height: 100vh;
        padding: 2rem;
    }
    
    .text-input-card {
        background: rgba(255, 255, 255, 0.95);
        border-radius: 20px;
        padding: 3rem;
        backdrop-filter: blur(10px);
        box-shadow: 0 20px 40px rgba(0,0,0,0.1);
    }
    
    .page-title {
        text-align: center;
        color: white;
        font-size: 4rem;
        margin-bottom: 3rem;
        text-shadow: 3px 3px 6px rgba(0,0,0,0.4);
        font-weight: bold;
    }
    
    .section-header {
        font-size: 2.5rem;
        color: #2d3436;
        margin-bottom: 1.5rem;
        font-weight: bold;
        text-align: center;
    }
    
    .format-section {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        padding: 2rem;
        border-radius: 15px;
        margin: 2rem 0;
        color: white;
    }
    
    @keyframes gradientShift {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }
    </style>
    """, unsafe_allow_html=True)
    
    st.markdown('<div class="text-page-container">', unsafe_allow_html=True)
    
    st.markdown('<div class="page-title">📝 Input Your Content</div>', unsafe_allow_html=True)
    
    with st.container():
        st.markdown('<div class="text-input-card">', unsafe_allow_html=True)
        
        # Back button
        if st.button("⬅️ Back to Dashboard", key="back_to_dash"):
            st.session_state.current_page = 'dashboard'
            st.rerun()
        
        # Language selection for input
        st.markdown('<div class="section-header">🌍 Input Language</div>', unsafe_allow_html=True)
        
        input_languages = {
            "🇺🇸 English": "en",
            "🇮🇳 Hindi": "hi", 
            "🇮🇳 Tamil": "ta",
            "🇪🇸 Spanish": "es",
            "🇫🇷 French": "fr",
            "🇩🇪 German": "de",
            "🇯🇵 Japanese": "ja",
            "🇰🇷 Korean": "ko"
        }
        
        input_lang_name = st.selectbox(
            "Select input language:",
            options=list(input_languages.keys()),
            index=0,
            key="input_language"
        )
        input_lang = input_languages[input_lang_name]
        st.session_state.input_language = input_lang
        
        # Input format selection
        st.markdown('<div class="format-section">', unsafe_allow_html=True)
        st.markdown('<div class="section-header" style="color: white;">📄 Choose Input Format</div>', unsafe_allow_html=True)
        
        input_format = st.radio(
            "How would you like to provide your content?",
            ["📝 Text", "📄 Document", "📂 Multiple Files", "🎤 Audio Recording"],
            horizontal=True,
            key="input_format"
        )
        
        st.markdown('</div>', unsafe_allow_html=True)
        
        text_content = ""
        
        if input_format == "📝 Text":
            text_content = st.text_area(
                "Enter your text here:",
                height=300,
                placeholder="Type or paste your text here to create an amazing audiobook...",
                key="main_text_input"
            )
        
        elif input_format == "📄 Document":
            uploaded_file = st.file_uploader(
                "Upload a document",
                type=['pdf', 'docx', 'txt'],
                help="📋 Upload PDF, DOCX, or TXT files",
                key="single_document"
            )
            
            if uploaded_file is not None:
                text_content = extract_text_from_file(uploaded_file)
                if text_content:
                    st.success(f"✅ Extracted {len(text_content)} characters from {uploaded_file.name}")
                    with st.expander("👀 Preview extracted text"):
                        st.text(text_content[:500] + "..." if len(text_content) > 500 else text_content)
        
        elif input_format == "📂 Multiple Files":
            uploaded_files = st.file_uploader(
                "Upload multiple files",
                type=['pdf', 'docx', 'txt'],
                accept_multiple_files=True,
                help="📚 Upload multiple PDF, DOCX, or TXT files to combine them",
                key="multiple_files"
            )
            
            if uploaded_files:
                text_parts = []
                for uploaded_file in uploaded_files:
                    file_text = extract_text_from_file(uploaded_file)
                    if file_text:
                        text_parts.append(f"=== {uploaded_file.name} ===\n{file_text}")
                
                text_content = "\n\n".join(text_parts)
                if text_content:
                    st.success(f"✅ Combined text from {len(uploaded_files)} files")
                    with st.expander("👀 Preview combined text"):
                        st.text(text_content[:500] + "..." if len(text_content) > 500 else text_content)
        
        elif input_format == "🎤 Audio Recording":
            st.info("🎤 Audio recording feature coming soon! For now, please use text input.")
            text_content = st.text_area(
                "Or enter text directly:",
                height=200,
                placeholder="Type your text here...",
                key="fallback_text"
            )
        
        # Show content status
        if text_content and text_content.strip():
            st.success(f"✅ Content ready: {len(text_content)} characters, ~{len(text_content.split())} words")
            
            col1, col2 = st.columns(2)
            with col2:
                if st.button("Next: Choose Tone ➡️", use_container_width=True, type="primary"):
                    st.session_state.original_text = text_content.strip()
                    st.session_state.current_page = 'tone_selection'
                    st.rerun()
        else:
            st.info("💡 Please provide some content to continue")
        
        st.markdown('</div>', unsafe_allow_html=True)
    
    st.markdown('</div>', unsafe_allow_html=True)