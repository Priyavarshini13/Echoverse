import streamlit as st
import os
import base64
from ui_components import UIComponents

def show_result_page():
    """Display audiobook result page"""
    
    # Custom CSS for result page
    st.markdown("""
    <style>
    .result-page-container {
        background: linear-gradient(135deg, #00b894 0%, #00cec9 25%, #74b9ff 50%, #a29bfe 75%, #fd79a8 100%);
        background-size: 400% 400%;
        animation: gradientShift 8s ease infinite;
        min-height: 100vh;
        padding: 2rem;
    }
    
    .result-card {
        background: rgba(255, 255, 255, 0.95);
        border-radius: 20px;
        padding: 2rem;
        backdrop-filter: blur(10px);
        box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        margin-bottom: 2rem;
    }
    
    .success-title {
        text-align: center;
        color: white;
        font-size: 3rem;
        margin-bottom: 2rem;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    }
    
    .audiobook-info {
        background: linear-gradient(135deg, #00cec9, #74b9ff);
        color: white;
        border-radius: 15px;
        padding: 2rem;
        text-align: center;
        margin: 2rem 0;
    }
    
    .info-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin: 1rem 0;
        padding: 0.5rem 0;
        border-bottom: 1px solid rgba(255,255,255,0.2);
    }
    
    .info-item:last-child {
        border-bottom: none;
    }
    
    .info-label {
        font-weight: bold;
        opacity: 0.9;
    }
    
    .info-value {
        font-weight: normal;
    }
    
    .action-buttons {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
        margin: 2rem 0;
    }
    
    @keyframes gradientShift {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }
    </style>
    """, unsafe_allow_html=True)
    
    st.markdown('<div class="result-page-container">', unsafe_allow_html=True)
    
    st.markdown('<div class="success-title">🎉 Your Audiobook is Ready!</div>', unsafe_allow_html=True)
    
    with st.container():
        st.markdown('<div class="result-card">', unsafe_allow_html=True)
        
        # Audiobook information
        st.markdown("""
        <div class="audiobook-info">
            <h3>📚 Audiobook Details</h3>
        </div>
        """, unsafe_allow_html=True)
        
        # Display audiobook info
        tone = st.session_state.get('selected_tone', 'Unknown')
        voice = st.session_state.get('selected_voice_name', 'Unknown')
        word_count = len(st.session_state.get('rewritten_text', '').split())
        user_language = st.session_state.get('user_language', 'en')
        
        language_names = {
            'en': 'English', 'hi': 'Hindi', 'ta': 'Tamil', 'es': 'Spanish',
            'fr': 'French', 'de': 'German', 'ja': 'Japanese', 'ko': 'Korean'
        }
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**📊 Statistics:**")
            st.markdown(f"• **Tone:** {tone}")
            st.markdown(f"• **Voice:** {voice}")
            st.markdown(f"• **Words:** {word_count}")
            st.markdown(f"• **Language:** {language_names.get(user_language, 'English')}")
        
        with col2:
            st.markdown("**🎨 Style:**")
            if tone == "Neutral":
                st.markdown("• Clear and professional")
                st.markdown("• Balanced narration")
            elif tone == "Suspenseful":
                st.markdown("• Thrilling and mysterious")
                st.markdown("• Engaging atmosphere")
            elif tone == "Inspiring":
                st.markdown("• Motivational and uplifting")
                st.markdown("• Energizing delivery")
        
        st.markdown("---")
        
        # Final text comparison
        if 'original_text' in st.session_state and 'rewritten_text' in st.session_state:
            st.markdown("### 📋 Final Comparison")
            
            col1, col2 = st.columns(2)
            with col1:
                st.markdown("**📝 Original Text**")
                st.text_area("Original:", st.session_state.original_text, height=150, disabled=True, key="final_orig", label_visibility="collapsed")
            
            with col2:
                st.markdown(f"**🎭 {tone} Version**")
                st.text_area("Rewritten:", st.session_state.rewritten_text, height=150, disabled=True, key="final_rewritten", label_visibility="collapsed")
        
        st.markdown("---")
        
        # Audio player and controls
        st.markdown("### 🎵 Your Audiobook")
        
        if 'audio_file' in st.session_state and st.session_state.audio_file:
            try:
                # Check if file exists
                if os.path.exists(st.session_state.audio_file):
                    # Load audio file
                    with open(st.session_state.audio_file, 'rb') as audio_file:
                        audio_bytes = audio_file.read()
                    
                    # Audio player
                    st.audio(audio_bytes, format='audio/mp3')
                    
                    # Download button
                    from datetime import datetime
                    filename = f"echoverse_audiobook_{datetime.now().strftime('%Y%m%d_%H%M%S')}.mp3"
                    
                    st.download_button(
                        label="📥 Download Audiobook",
                        data=audio_bytes,
                        file_name=filename,
                        mime="audio/mpeg",
                        use_container_width=True,
                        type="primary",
                        help="Download your audiobook as MP3 file"
                    )
                    
                    st.success("✅ You can now listen to your audiobook or download it!")
                    
                else:
                    st.error("❌ Audio file not found. Please try creating the audiobook again.")
                    
            except Exception as e:
                st.error(f"❌ Error loading audio: {str(e)}")
        else:
            st.warning("⚠️ No audio file available. Please go back and generate the audiobook.")
        
        st.markdown("---")
        
        # Action buttons
        st.markdown("### 🚀 What's Next?")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("🆕 Create Another Audiobook", use_container_width=True):
                # Clear current session data but keep user preferences
                keys_to_keep = ['user_language', 'recent_projects']
                for key in list(st.session_state.keys()):
                    if key not in keys_to_keep:
                        del st.session_state[key]
                st.session_state.current_page = 'dashboard'
                st.rerun()
        
        with col2:
            if st.button("🏠 Back to Dashboard", use_container_width=True):
                st.session_state.current_page = 'dashboard'
                st.rerun()
        
        with col3:
            if st.button("🔧 Try Different Voice", use_container_width=True):
                st.session_state.current_page = 'voice_selection'
                st.rerun()
        
        # Share section
        st.markdown("---")
        st.markdown("### 📤 Share Your Experience")
        st.info("💡 **Tip:** Save this audiobook to your device and share it with friends and family!")
        
        st.markdown('</div>', unsafe_allow_html=True)
    
    st.markdown('</div>', unsafe_allow_html=True)