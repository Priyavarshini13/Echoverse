import streamlit as st
import time

def show_splash_screen():
    """Display splash screen for 5 seconds"""
    
    # Custom CSS for splash screen
    st.markdown("""
    <style>
    .splash-container {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100vh;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        text-align: center;
        color: white;
        position: relative;
        overflow: hidden;
    }
    
    .welcome-background {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        font-size: 8rem;
        font-weight: bold;
        color: rgba(255,255,255,0.1);
        white-space: nowrap;
        z-index: 1;
        user-select: none;
        pointer-events: none;
    }
    
    .splash-logo {
        font-size: 6rem;
        margin-bottom: 20px;
        animation: pulse 2s infinite;
        position: relative;
        z-index: 2;
    }
    
    .splash-title {
        font-size: 3rem;
        font-weight: bold;
        margin-bottom: 10px;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        position: relative;
        z-index: 2;
    }
    
    .splash-subtitle {
        font-size: 1.5rem;
        opacity: 0.9;
        margin-bottom: 30px;
        position: relative;
        z-index: 2;
    }
    
    .loading-animation {
        width: 60px;
        height: 60px;
        border: 3px solid rgba(255,255,255,0.3);
        border-top: 3px solid white;
        border-radius: 50%;
        animation: spin 1s linear infinite;
        margin: 0 auto;
        position: relative;
        z-index: 2;
    }
    
    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.1); }
        100% { transform: scale(1); }
    }
    
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Splash screen content
    st.markdown("""
    <div class="splash-container">
        <div class="welcome-background">Welcome to EchoVerse</div>
        <div class="splash-logo">🎧</div>
        <div class="splash-title">EchoVerse</div>
        <div class="splash-subtitle">AI-Powered Audiobook Creator</div>
        <div class="loading-animation"></div>
    </div>
    """, unsafe_allow_html=True)
    
    # JavaScript auto-redirect after 5 seconds
    st.markdown("""
    <script>
    setTimeout(function() {
        window.location.reload();
    }, 5000);
    </script>
    """, unsafe_allow_html=True)
    
    # Alternative: Use placeholder that updates
    placeholder = st.empty()
    with placeholder:
        for i in range(5, 0, -1):
            st.markdown(f"<p style='text-align:center; color:white; font-size:1.2rem;'>Redirecting in {i}...</p>", unsafe_allow_html=True)
            time.sleep(1)
    
    st.session_state.show_splash = False
    st.rerun()