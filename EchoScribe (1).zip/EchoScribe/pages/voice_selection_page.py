import streamlit as st
import tempfile
import os
from gtts import gTTS
import time
from datetime import datetime

def show_voice_selection_page():
    """Display voice selection page"""
    
    # Custom CSS for voice selection page
    st.markdown("""
    <style>
    .voice-page-container {
        background: linear-gradient(135deg, #6c5ce7 0%, #a29bfe 25%, #fd79a8 50%, #fdcb6e 75%, #e17055 100%);
        background-size: 400% 400%;
        animation: gradientShift 10s ease infinite;
        min-height: 100vh;
        padding: 2rem;
    }
    
    .voice-selection-card {
        background: rgba(255, 255, 255, 0.95);
        border-radius: 20px;
        padding: 2rem;
        backdrop-filter: blur(10px);
        box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        margin-bottom: 2rem;
    }
    
    .page-title {
        text-align: center;
        color: white;
        font-size: 2.5rem;
        margin-bottom: 2rem;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    }
    
    .voice-card {
        background: linear-gradient(135deg, #00cec9, #6c5ce7);
        color: white;
        border-radius: 15px;
        padding: 1.5rem;
        text-align: center;
        margin: 1rem 0;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        cursor: pointer;
        border: none;
    }
    
    .voice-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 10px 25px rgba(0,0,0,0.2);
    }
    
    .comparison-container {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 2rem;
        margin: 2rem 0;
    }
    
    .text-comparison-card {
        background: rgba(255,255,255,0.1);
        border-radius: 15px;
        padding: 1.5rem;
        backdrop-filter: blur(5px);
    }
    
    @keyframes gradientShift {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }
    </style>
    """, unsafe_allow_html=True)
    
    st.markdown('<div class="voice-page-container">', unsafe_allow_html=True)
    
    st.markdown('<div class="page-title">🗣️ Choose Your Voice</div>', unsafe_allow_html=True)
    
    with st.container():
        st.markdown('<div class="voice-selection-card">', unsafe_allow_html=True)
        
        # Back button
        if st.button("⬅️ Back to Tone Selection", key="back_from_voice"):
            st.session_state.current_page = 'tone_selection'
            st.rerun()
        
        # Show text comparison
        if 'original_text' in st.session_state and 'rewritten_text' in st.session_state:
            st.markdown("### 📊 Text Comparison")
            
            col1, col2 = st.columns(2)
            with col1:
                st.markdown("**📝 Original Text**")
                st.text_area("", st.session_state.original_text, height=200, disabled=True, key="orig_comparison", label_visibility="collapsed")
                st.caption(f"Words: {len(st.session_state.original_text.split())}")
            
            with col2:
                st.markdown(f"**🎭 {st.session_state.get('selected_tone', 'Rewritten')} Version**")
                st.text_area("", st.session_state.rewritten_text, height=200, disabled=True, key="rewritten_comparison", label_visibility="collapsed")
                st.caption(f"Words: {len(st.session_state.rewritten_text.split())}")
        
        st.markdown("---")
        st.markdown("### 🎤 Select Your Voice")
        
        # Get user language
        user_language = st.session_state.get('user_language', 'en')
        
        # Voice options based on language
        voices = get_available_voices(user_language)
        
        # Display voice options
        for voice in voices:
            col1, col2 = st.columns([3, 1])
            
            with col1:
                st.markdown(f"""
                <div class="voice-card">
                    <h4>🗣️ {voice['name']}</h4>
                    <p>Perfect for your audiobook narration</p>
                </div>
                """, unsafe_allow_html=True)
            
            with col2:
                if st.button(f"Choose {voice['name']}", key=f"voice_{voice['code']}", use_container_width=True):
                    st.session_state.selected_voice = voice['code']
                    st.session_state.selected_voice_name = voice['name']
                    generate_audiobook()
        
        st.markdown('</div>', unsafe_allow_html=True)
    
    st.markdown('</div>', unsafe_allow_html=True)

def get_available_voices(language_code):
    """Get available voices for the specified language"""
    voices = {
        'en': [
            {'name': 'Lisa (Female)', 'code': 'lisa'},
            {'name': 'Michael (Male)', 'code': 'michael'},
            {'name': 'Allison (Female)', 'code': 'allison'}
        ],
        'hi': [
            {'name': 'Priya (Female)', 'code': 'priya'},
            {'name': 'Raj (Male)', 'code': 'raj'}
        ],
        'ta': [
            {'name': 'Meera (Female)', 'code': 'meera'},
            {'name': 'Kumar (Male)', 'code': 'kumar'}
        ],
        'es': [
            {'name': 'Maria (Female)', 'code': 'maria'},
            {'name': 'Carlos (Male)', 'code': 'carlos'}
        ],
        'fr': [
            {'name': 'Sophie (Female)', 'code': 'sophie'},
            {'name': 'Pierre (Male)', 'code': 'pierre'}
        ]
    }
    
    return voices.get(language_code, voices['en'])

def text_to_speech(text, language_code, voice_code):
    """Convert text to speech and save as MP3"""
    try:
        # Create TTS object
        tts = gTTS(text=text, lang=language_code, slow=False)
        
        # Generate unique filename
        timestamp = int(time.time())
        temp_dir = tempfile.mkdtemp()
        audio_file_path = os.path.join(temp_dir, f"audiobook_{timestamp}.mp3")
        
        # Save audio file
        tts.save(audio_file_path)
        
        return audio_file_path
        
    except Exception as e:
        st.error(f"Error generating speech: {str(e)}")
        return None

def generate_audiobook():
    """Generate the audiobook with selected voice"""
    try:
        user_language = st.session_state.get('user_language', 'en')
        
        with st.spinner("🎧 Creating your audiobook... This may take a moment."):
            audio_file_path = text_to_speech(
                st.session_state.rewritten_text,
                user_language,
                st.session_state.selected_voice
            )
            
            if audio_file_path:
                st.session_state.audio_file = audio_file_path
                st.success(f"✅ Audiobook created successfully with {st.session_state.selected_voice_name} voice!")
                
                # Add to recent projects
                if 'recent_projects' not in st.session_state:
                    st.session_state.recent_projects = []
                
                project = {
                    'title': f"{st.session_state.selected_tone} Audiobook",
                    'date': datetime.now().strftime("%Y-%m-%d %H:%M"),
                    'tone': st.session_state.selected_tone,
                    'voice': st.session_state.selected_voice_name,
                    'words': len(st.session_state.rewritten_text.split())
                }
                st.session_state.recent_projects.append(project)
                
                st.session_state.current_page = 'result'
                st.rerun()
            else:
                st.error("Failed to create audiobook. Please try again.")
                
    except Exception as e:
        st.error(f"Error generating audiobook: {str(e)}")