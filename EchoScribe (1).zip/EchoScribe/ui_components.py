import streamlit as st
import time
from gtts import gTTS
import pygame
import tempfile
import os

class UIComponents:
    def __init__(self):
        self.temp_dir = tempfile.mkdtemp()
        
        # Initialize pygame mixer for audio instructions
        try:
            pygame.mixer.init()
        except:
            pass
        
        # Custom CSS for better accessibility
        self.inject_custom_css()
    
    def inject_custom_css(self):
        """Inject custom CSS for better accessibility and UI"""
        st.markdown("""
        <style>
        /* Large button styling */
        .stButton > button {
            font-size: 18px !important;
            padding: 15px 25px !important;
            border-radius: 10px !important;
            border: 2px solid #ddd !important;
            transition: all 0.3s ease !important;
            font-weight: bold !important;
        }
        
        .stButton > button:hover {
            border-color: #FF6B6B !important;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2) !important;
            transform: translateY(-2px) !important;
        }
        
        /* High contrast text areas */
        .stTextArea textarea {
            font-size: 16px !important;
            border: 2px solid #ddd !important;
            border-radius: 8px !important;
        }
        
        /* Large file uploader */
        .stFileUploader {
            border: 3px dashed #FF6B6B !important;
            border-radius: 10px !important;
            padding: 20px !important;
            text-align: center !important;
        }
        
        /* Progress indicators */
        .stProgress .stProgress-bar {
            background: linear-gradient(90deg, #FF6B6B, #4ECDC4) !important;
        }
        
        /* Audio player styling */
        .stAudio {
            margin: 20px 0 !important;
        }
        
        /* Success/Error message styling */
        .stAlert {
            font-size: 16px !important;
            padding: 15px !important;
            border-radius: 8px !important;
        }
        
        /* Large headings for visibility */
        h1 {
            font-size: 2.5rem !important;
            color: #333 !important;
            text-align: center !important;
            margin-bottom: 30px !important;
        }
        
        h3 {
            font-size: 1.8rem !important;
            color: #444 !important;
            margin: 25px 0 15px 0 !important;
        }
        
        /* Column spacing */
        .block-container {
            padding-top: 2rem !important;
            padding-bottom: 2rem !important;
        }
        
        /* Loading spinner styling */
        .stSpinner {
            text-align: center !important;
        }
        
        /* Download button special styling */
        .stDownloadButton > button {
            background: linear-gradient(90deg, #4ECDC4, #44A08D) !important;
            color: white !important;
            font-size: 18px !important;
            padding: 15px 30px !important;
            border: none !important;
        }
        </style>
        """, unsafe_allow_html=True)
    
    def create_language_flag_button(self, language_code, language_name, flag_emoji, key_prefix):
        """Create a language selection button with flag"""
        button_text = f"{flag_emoji} {language_name}"
        return st.button(
            button_text,
            key=f"{key_prefix}_{language_code}",
            use_container_width=True,
            help=f"Select {language_name}"
        )
    
    def create_large_icon_button(self, icon, text, description=None, key=None):
        """Create a large button with icon and text"""
        button_content = f"{icon} {text}"
        if description:
            button_content += f"\n{description}"
        
        return st.button(
            button_content,
            key=key,
            use_container_width=True,
            help=description
        )
    
    def show_progress_indicator(self, current_step, total_steps, step_names):
        """Show visual progress indicator"""
        progress = current_step / total_steps
        
        st.markdown("### Progress")
        st.progress(progress)
        
        # Step indicator
        cols = st.columns(total_steps)
        for i, step_name in enumerate(step_names):
            with cols[i]:
                if i < current_step:
                    st.markdown(f"✅ **{step_name}**")
                elif i == current_step:
                    st.markdown(f"🔄 **{step_name}**")
                else:
                    st.markdown(f"⭕ {step_name}")
    
    def play_audio_instruction(self, text, language_code='en'):
        """Play audio instruction for the given text"""
        try:
            # Create audio instruction toggle
            if 'audio_enabled' not in st.session_state:
                st.session_state.audio_enabled = True
            
            # Audio toggle in sidebar
            with st.sidebar:
                audio_enabled = st.checkbox("🔊 Audio Instructions", value=st.session_state.audio_enabled)
                st.session_state.audio_enabled = audio_enabled
            
            if not st.session_state.audio_enabled:
                return
            
            # Generate TTS for instruction
            tts = gTTS(text=text, lang=language_code, slow=False)
            
            # Create temporary file
            timestamp = int(time.time())
            audio_file_path = os.path.join(self.temp_dir, f"instruction_{timestamp}.mp3")
            tts.save(audio_file_path)
            
            # Auto-play the instruction
            with open(audio_file_path, 'rb') as audio_file:
                audio_bytes = audio_file.read()
            
            # Display audio player (auto-play not supported in most browsers for security)
            st.audio(audio_bytes, format='audio/mp3')
            
            # Clean up the file after a delay
            time.sleep(1)
            try:
                os.remove(audio_file_path)
            except:
                pass
                
        except Exception as e:
            # Silent fail for audio instructions to not interrupt the main flow
            pass
    
    def show_text_comparison(self, original_text, rewritten_text, tone):
        """Show side-by-side text comparison"""
        st.markdown("### 📊 Text Comparison")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**📝 Original Text**")
            st.text_area(
                "",
                original_text,
                height=250,
                disabled=True,
                key="original_comparison",
                help="Your original content"
            )
            
            # Word count
            original_words = len(original_text.split())
            st.caption(f"Word count: {original_words}")
        
        with col2:
            st.markdown(f"**🎭 {tone} Version**")
            st.text_area(
                "",
                rewritten_text,
                height=250,
                disabled=True,
                key="rewritten_comparison",
                help=f"Content rewritten in {tone} tone"
            )
            
            # Word count
            rewritten_words = len(rewritten_text.split())
            st.caption(f"Word count: {rewritten_words}")
    
    def show_loading_animation(self, message="Processing..."):
        """Show loading animation with message"""
        with st.spinner(message):
            # Add a brief delay to show the spinner
            time.sleep(0.5)
    
    def create_audio_controls(self, audio_file_path=None):
        """Create audio playback controls"""
        if not audio_file_path or not os.path.exists(audio_file_path):
            st.warning("⚠️ Audio file not available")
            return
        
        st.markdown("### 🎵 Audio Controls")
        
        try:
            # Load audio file
            with open(audio_file_path, 'rb') as audio_file:
                audio_bytes = audio_file.read()
            
            # Audio player
            st.audio(audio_bytes, format='audio/mp3')
            
            # Download button
            filename = f"echoverse_audiobook_{int(time.time())}.mp3"
            st.download_button(
                label="📥 Download Audiobook",
                data=audio_bytes,
                file_name=filename,
                mime="audio/mpeg",
                use_container_width=True,
                help="Download your audiobook as MP3"
            )
            
        except Exception as e:
            st.error(f"❌ Error loading audio: {str(e)}")
    
    def show_error_message(self, error_message, suggestions=None):
        """Show formatted error message with suggestions"""
        st.error(f"❌ **Error:** {error_message}")
        
        if suggestions:
            st.markdown("**💡 Suggestions:**")
            for suggestion in suggestions:
                st.markdown(f"- {suggestion}")
    
    def show_success_message(self, success_message, details=None):
        """Show formatted success message"""
        st.success(f"✅ {success_message}")
        
        if details:
            st.info(f"ℹ️ {details}")
    
    def create_navigation_buttons(self, show_back=True, show_next=True, back_text="⬅️ Back", next_text="Next ➡️", back_callback=None, next_callback=None):
        """Create standardized navigation buttons"""
        col1, col2 = st.columns(2)
        
        with col1:
            if show_back:
                back_clicked = st.button(back_text, use_container_width=True)
                if back_clicked and back_callback:
                    back_callback()
                return back_clicked, None
        
        with col2:
            if show_next:
                next_clicked = st.button(next_text, use_container_width=True)
                if next_clicked and next_callback:
                    next_callback()
                if show_back:
                    return None, next_clicked
                else:
                    return next_clicked, None
        
        return None, None
    
    def show_feature_highlight(self, title, description, icon="✨"):
        """Show feature highlight box"""
        st.markdown(f"""
        <div style="
            border: 2px solid #4ECDC4;
            border-radius: 10px;
            padding: 20px;
            margin: 15px 0;
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
        ">
            <h4 style="color: #333; margin: 0 0 10px 0;">{icon} {title}</h4>
            <p style="color: #666; margin: 0; font-size: 16px;">{description}</p>
        </div>
        """, unsafe_allow_html=True)
    
    def cleanup_temp_files(self):
        """Clean up temporary files"""
        try:
            for file in os.listdir(self.temp_dir):
                file_path = os.path.join(self.temp_dir, file)
                if os.path.isfile(file_path):
                    os.remove(file_path)
        except:
            pass
