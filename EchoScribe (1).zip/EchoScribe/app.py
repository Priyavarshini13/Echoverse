import streamlit as st
import os
import sys
import time

# Add pages directory to path
sys.path.append('pages')

# Import page modules
from pages.splash import show_splash_screen
from pages.login import show_login_page  
from pages.dashboard import show_dashboard
from pages.text_input_page import show_text_input_page
from pages.tone_selection_page import show_tone_selection_page
from pages.voice_selection_page import show_voice_selection_page
from pages.result_page import show_result_page

def main():
    # Page configuration
    st.set_page_config(
        page_title="EchoVerse - AI Audiobook Creator",
        page_icon="🎧",
        layout="wide",
        initial_sidebar_state="collapsed"
    )
    
    # Custom CSS for interactive design and larger fonts
    st.markdown("""
    <style>
    /* Global font size increase */
    .main .block-container {
        font-size: 1.2rem;
        max-width: 1200px;
        padding-top: 2rem;
    }
    
    /* Large interactive buttons */
    .stButton > button {
        font-size: 1.4rem !important;
        padding: 0.75rem 2rem !important;
        border-radius: 15px !important;
        font-weight: bold !important;
        border: 3px solid transparent !important;
        transition: all 0.3s ease !important;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2) !important;
    }
    
    .stButton > button:hover {
        transform: translateY(-2px) !important;
        box-shadow: 0 8px 25px rgba(0,0,0,0.3) !important;
    }
    
    /* Large selectbox */
    .stSelectbox > div > div {
        font-size: 1.3rem !important;
    }
    
    /* Large text areas */
    .stTextArea textarea {
        font-size: 1.2rem !important;
        border-radius: 10px !important;
    }
    
    /* Colorful backgrounds */
    .main {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    }
    
    /* Large headings */
    h1 {
        font-size: 3.5rem !important;
        text-align: center !important;
        margin-bottom: 2rem !important;
    }
    
    h2 {
        font-size: 2.5rem !important;
        margin-bottom: 1.5rem !important;
    }
    
    h3 {
        font-size: 2rem !important;
        margin-bottom: 1rem !important;
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Initialize session state
    if 'show_splash' not in st.session_state:
        st.session_state.show_splash = True
    if 'current_page' not in st.session_state:
        st.session_state.current_page = 'login'
    if 'user_language' not in st.session_state:
        st.session_state.user_language = 'en'
    
    # Handle page routing
    if st.session_state.show_splash:
        show_splash_screen()
    elif st.session_state.current_page == 'login':
        show_login_page()
    elif st.session_state.current_page == 'dashboard':
        show_dashboard()
    elif st.session_state.current_page == 'text_input':
        show_text_input_page()
    elif st.session_state.current_page == 'tone_selection':
        show_tone_selection_page()
    elif st.session_state.current_page == 'voice_selection':
        show_voice_selection_page()
    elif st.session_state.current_page == 'result':
        show_result_page()
    else:
        # Fallback to dashboard
        st.session_state.current_page = 'dashboard'
        st.rerun()

if __name__ == "__main__":
    main()