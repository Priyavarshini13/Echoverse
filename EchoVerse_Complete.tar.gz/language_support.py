import streamlit as st

class LanguageManager:
    def __init__(self):
        self.supported_languages = {
            'en': {
                'name': 'English',
                'flag': '🇺🇸',
                'tts_code': 'en',
                'voice_options': ['en-US', 'en-GB', 'en-AU']
            },
            'hi': {
                'name': 'Hindi',
                'flag': '🇮🇳',
                'tts_code': 'hi',
                'voice_options': ['hi-IN']
            },
            'ta': {
                'name': 'Tamil',
                'flag': '🇮🇳',
                'tts_code': 'ta',
                'voice_options': ['ta-IN']
            },
            'es': {
                'name': 'Spanish',
                'flag': '🇪🇸',
                'tts_code': 'es',
                'voice_options': ['es-ES', 'es-MX']
            },
            'fr': {
                'name': 'French',
                'flag': '🇫🇷',
                'tts_code': 'fr',
                'voice_options': ['fr-FR', 'fr-CA']
            },
            'de': {
                'name': 'German',
                'flag': '🇩🇪',
                'tts_code': 'de',
                'voice_options': ['de-DE']
            },
            'ja': {
                'name': 'Japanese',
                'flag': '🇯🇵',
                'tts_code': 'ja',
                'voice_options': ['ja-JP']
            },
            'ko': {
                'name': 'Korean',
                'flag': '🇰🇷',
                'tts_code': 'ko',
                'voice_options': ['ko-KR']
            }
        }
        
        # Audio instruction texts in different languages
        self.instructions = {
            'en': {
                'welcome': "Welcome to EchoVerse. Please select your preferred language.",
                'input_selected': "You selected {language} as input language.",
                'output_selected': "You selected {language} as output language. Now choose your input method.",
                'choose_input': "Choose how you want to provide your content.",
                'type_text': "You chose to type text. Please enter your content.",
                'upload_file': "You chose to upload a file. Please select your document.",
                'record_voice': "You chose to record your voice. Please use the microphone.",
                'text_received': "Text received. Now please select the tone for your audiobook.",
                'file_processed': "File processed. Now please select the tone for your audiobook.",
                'speech_processed': "Speech processed. Now please select the tone for your audiobook.",
                'choose_tone': "Please choose the tone for your audiobook.",
                'tone_selected': "Text rewritten in {tone} tone. Now please select a voice.",
                'choose_voice': "Please choose a voice for your audiobook.",
                'audiobook_ready': "Your audiobook is ready!",
                'audiobook_created': "Your audiobook has been created successfully.",
                'recording_started': "Recording started. Please speak now.",
                'recording_stopped': "Recording stopped. Processing your speech.",
                'playing_recording': "Playing your recording."
            },
            'hi': {
                'welcome': "EchoVerse में आपका स्वागत है। कृपया अपनी पसंदीदा भाषा चुनें।",
                'input_selected': "आपने {language} को इनपुट भाषा के रूप में चुना है।",
                'output_selected': "आपने {language} को आउटपुट भाषा के रूप में चुना है। अब अपना इनपुट तरीका चुनें।",
                'choose_input': "चुनें कि आप अपनी सामग्री कैसे प्रदान करना चाहते हैं।",
                'type_text': "आपने टेक्स्ट टाइप करना चुना है। कृपया अपनी सामग्री दर्ज करें।",
                'upload_file': "आपने फ़ाइल अपलोड करना चुना है। कृपया अपना दस्तावेज़ चुनें।",
                'record_voice': "आपने अपनी आवाज़ रिकॉर्ड करना चुना है। कृपया माइक्रोफ़ोन का उपयोग करें।",
                'text_received': "टेक्स्ट मिल गया। अब कृपया अपनी ऑडियोबुक के लिए टोन चुनें।",
                'file_processed': "फ़ाइल प्रोसेस हो गई। अब कृपया अपनी ऑडियोबुक के लिए टोन चुनें।",
                'speech_processed': "भाषण प्रोसेस हो गया। अब कृपया अपनी ऑडियोबुक के लिए टोन चुनें।",
                'choose_tone': "कृपया अपनी ऑडियोबुक के लिए टोन चुनें।",
                'tone_selected': "{tone} टोन में टेक्स्ट फिर से लिखा गया। अब कृपया एक आवाज़ चुनें।",
                'choose_voice': "कृपया अपनी ऑडियोबुक के लिए एक आवाज़ चुनें।",
                'audiobook_ready': "आपकी ऑडियोबुक तैयार है!",
                'audiobook_created': "आपकी ऑडियोबुक सफलतापूर्वक बनाई गई है।",
                'recording_started': "रिकॉर्डिंग शुरू हो गई। कृपया अब बोलें।",
                'recording_stopped': "रिकॉर्डिंग रुक गई। आपके भाषण को प्रोसेस कर रहे हैं।",
                'playing_recording': "आपकी रिकॉर्डिंग चला रहे हैं।"
            },
            'ta': {
                'welcome': "EchoVerse-க்கு வரவேற்கிறோம். தயவுசெய்து உங்கள் விருப்பமான மொழியைத் தேர்ந்தெடுக்கவும்.",
                'input_selected': "நீங்கள் {language} ஐ உள்ளீட்டு மொழியாகத் தேர்ந்தெடுத்துள்ளீர்கள்.",
                'output_selected': "நீங்கள் {language} ஐ வெளியீட்டு மொழியாகத் தேர்ந்தெடுத்துள்ளீர்கள். இப்போது உங்கள் உள்ளீட்டு முறையைத் தேர்ந்தெடுக்கவும்.",
                'choose_input': "உங்கள் உள்ளடக்கத்தை எவ்வாறு வழங்க விரும்புகிறீர்கள் என்பதைத் தேர்ந்தெடுக்கவும்.",
                'type_text': "நீங்கள் உரை தட்டச்சு செய்வதைத் தேர்ந்தெடுத்துள்ளீர்கள். தயவுசெய்து உங்கள் உள்ளடக்கத்தை உள்ளிடவும்.",
                'upload_file': "நீங்கள் கோப்பைப் பதிவேற்றுவதைத் தேர்ந்தெடுத்துள்ளீர்கள். தயவுசெய்து உங்கள் ஆவணத்தைத் தேர்ந்தெடுக்கவும்.",
                'record_voice': "நீங்கள் உங்கள் குரலைப் பதிவு செய்வதைத் தேர்ந்தெடுத்துள்ளீர்கள். தயவுசெய்து மைக்ரோஃபோனைப் பயன்படுத்தவும்.",
                'text_received': "உரை பெறப்பட்டது. இப்போது தயவுசெய்து உங்கள் ஆடியோ புத்தகத்திற்கான டோனைத் தேர்ந்தெடுக்கவும்.",
                'file_processed': "கோப்பு செயலாக்கப்பட்டது. இப்போது தயவுசெய்து உங்கள் ஆடியோ புத்தகத்திற்கான டோனைத் தேர்ந்தெடுக்கவும்.",
                'speech_processed': "பேச்சு செயலாக்கப்பட்டது. இப்போது தயவுசெய்து உங்கள் ஆடியோ புத்தகத்திற்கான டோனைத் தேர்ந்தெடுக்கவும்.",
                'choose_tone': "தயவுசெய்து உங்கள் ஆடியோ புத்தகத்திற்கான டோனைத் தேர்ந்தெடுக்கவும்.",
                'tone_selected': "{tone} டோனில் உரை மீண்டும் எழுதப்பட்டது. இப்போது தயவுசெய்து ஒரு குரலைத் தேர்ந்தெடுக்கவும்.",
                'choose_voice': "தயவுசெய்து உங்கள் ஆடியோ புத்தகத்திற்கான குரலைத் தேர்ந்தெடுக்கவும்.",
                'audiobook_ready': "உங்கள் ஆடியோ புத்தகம் தயார்!",
                'audiobook_created': "உங்கள் ஆடியோ புத்தகம் வெற்றிகரமாக உருவாக்கப்பட்டது.",
                'recording_started': "பதிவு தொடங்கியது. தயவுசெய்து இப்போது பேசவும்.",
                'recording_stopped': "பதிவு நிறுத்தப்பட்டது. உங்கள் பேச்சைச் செயலாக்குகிறோம்.",
                'playing_recording': "உங்கள் பதிவை இயக்குகிறோம்."
            }
        }
    
    def get_supported_languages(self):
        """Return dictionary of supported languages"""
        return self.supported_languages
    
    def get_language_info(self, language_code):
        """Get information about a specific language"""
        return self.supported_languages.get(language_code, self.supported_languages['en'])
    
    def get_instruction_text(self, instruction_key, language_code='en', **kwargs):
        """Get instruction text in specified language"""
        try:
            language_instructions = self.instructions.get(language_code, self.instructions['en'])
            instruction_text = language_instructions.get(instruction_key, instruction_key)
            
            # Format the instruction with any provided kwargs
            if kwargs:
                instruction_text = instruction_text.format(**kwargs)
            
            return instruction_text
            
        except Exception as e:
            # Fallback to English if there's any error
            english_instructions = self.instructions['en']
            instruction_text = english_instructions.get(instruction_key, instruction_key)
            if kwargs:
                try:
                    instruction_text = instruction_text.format(**kwargs)
                except:
                    pass
            return instruction_text
    
    def get_tts_language_code(self, language_code):
        """Get the correct TTS language code for a given language"""
        language_info = self.get_language_info(language_code)
        return language_info['tts_code']
    
    def get_voice_options(self, language_code):
        """Get available voice options for a language"""
        language_info = self.get_language_info(language_code)
        return language_info['voice_options']
    
    def is_language_supported(self, language_code):
        """Check if a language is supported"""
        return language_code in self.supported_languages
    
    def get_language_name(self, language_code):
        """Get the display name of a language"""
        language_info = self.get_language_info(language_code)
        return language_info['name']
    
    def get_language_flag(self, language_code):
        """Get the flag emoji for a language"""
        language_info = self.get_language_info(language_code)
        return language_info['flag']
