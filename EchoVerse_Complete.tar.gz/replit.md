# EchoVerse - AI Audiobook Creator

## Overview

EchoVerse is a multilingual AI-powered audiobook creation platform built with Streamlit. The application transforms text content into engaging audiobooks by rewriting text with different tones (neutral, suspenseful, inspiring) and converting it to natural-sounding speech. It supports multiple input formats (text, files, images via OCR, voice recording) and outputs audio in various languages with selectable voices. The platform is designed with accessibility in mind, featuring audio-guided navigation and large UI elements for users with varying literacy levels.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Streamlit-based web application with custom CSS styling
- **UI Design**: Step-by-step wizard interface with large buttons and high-contrast visuals
- **Accessibility Features**: Audio-guided navigation, multilingual support with flag icons, and visual animations
- **State Management**: Session-based state management for multi-step workflow (language selection → input → processing → output)
- **Audio Playback**: Pygame-based audio player integrated into the UI

### Backend Architecture
- **Core Processing**: Modular architecture with separate processors for audio, text, language, and UI components
- **Text Processing**: IBM Granite 3.0 8B Instruct model for tone-adaptive text rewriting using Hugging Face Transformers
- **Audio Generation**: Google Text-to-Speech (gTTS) for multilingual speech synthesis
- **File Processing**: Support for multiple input formats (PDF via PyPDF2, DOCX via python-docx, plain text)
- **Caching Strategy**: Streamlit's @st.cache_resource decorator for model loading and processor initialization

### Language Support Architecture
- **Multilingual Framework**: Centralized language management with support for English, Hindi, Tamil, Spanish, French, German, Japanese, and Korean
- **Voice Selection**: Language-specific voice options with gender-based selection
- **TTS Integration**: Language code mapping for proper text-to-speech conversion

### Data Processing Pipeline
1. **Input Stage**: Multi-format content ingestion (text, files, images, voice)
2. **Text Extraction**: Format-specific parsers for different file types
3. **Text Rewriting**: AI-powered tone transformation using IBM Granite model
4. **Audio Generation**: Text-to-speech conversion with voice and language selection
5. **Output Delivery**: Audio playback and download functionality

## External Dependencies

### AI/ML Services
- **IBM Granite 3.0 8B Instruct**: Primary language model for text rewriting and tone adaptation
- **Hugging Face Transformers**: Model loading and inference pipeline
- **Google Text-to-Speech (gTTS)**: Multilingual speech synthesis

### Core Libraries
- **Streamlit**: Web application framework and UI components
- **PyGame**: Audio playback and mixer functionality
- **PyPDF2**: PDF text extraction
- **python-docx**: Microsoft Word document processing

### File Processing
- **tempfile**: Temporary file management for audio processing
- **pathlib**: File system path operations
- **base64**: File encoding for download functionality

### Future Integrations (Based on Architecture)
- **OCR Service**: pytesseract for image text extraction
- **Database**: SQLite or Firebase for user data and usage tracking
- **Premium Features**: Subscription management system
- **Voice Recording**: Audio capture capabilities for voice input