import streamlit as st
import os
from gtts import gTTS
import tempfile
import base64
import time
from PyPDF2 import PdfReader
from docx import Document
import re

def extract_text_from_file(uploaded_file):
    """Extract text from uploaded files"""
    try:
        if uploaded_file.type == "application/pdf":
            # PDF extraction
            pdf_reader = PdfReader(uploaded_file)
            text = ""
            for page in pdf_reader.pages:
                text += page.extract_text() + "\n"
            return text.strip()
        
        elif uploaded_file.type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
            # DOCX extraction
            doc = Document(uploaded_file)
            text = ""
            for paragraph in doc.paragraphs:
                text += paragraph.text + "\n"
            return text.strip()
        
        elif uploaded_file.type == "text/plain":
            # TXT extraction
            text = uploaded_file.read().decode('utf-8')
            return text.strip()
        
        else:
            st.error(f"Unsupported file type: {uploaded_file.type}")
            return None
            
    except Exception as e:
        st.error(f"Error extracting text from {uploaded_file.name}: {str(e)}")
        return None

def rewrite_with_tone(text, tone):
    """Simple rule-based tone rewriting"""
    sentences = re.split(r'[.!?]+', text)
    rewritten_sentences = []
    
    for sentence in sentences:
        if not sentence.strip():
            continue
            
        if tone == "Suspenseful":
            # Add suspenseful elements
            sentence = sentence.replace(" said ", " whispered ")
            sentence = sentence.replace(" walked ", " crept ")
            sentence = sentence.replace(" looked ", " peered ")
            if len(sentence.split()) > 5:
                sentence = f"Suddenly, {sentence.strip()}"
            sentence += "..."
            
        elif tone == "Inspiring":
            # Add motivational elements
            sentence = sentence.replace(" can't ", " can ")
            sentence = sentence.replace(" impossible ", " achievable ")
            sentence = sentence.replace(" difficult ", " rewarding ")
            if len(sentence.split()) > 3:
                starters = ["Remarkably, ", "Incredibly, ", "With passion, ", "Courageously, "]
                import random
                sentence = random.choice(starters) + sentence.strip()
            sentence += "!"
            
        else:  # Neutral
            sentence = sentence.replace("...", ".").replace("!!!", "!")
            sentence = re.sub(r'\s+', ' ', sentence)
            sentence = sentence.strip() + "."
        
        rewritten_sentences.append(sentence)
    
    return " ".join(rewritten_sentences)

def convert_text_to_speech(text, voice_code, output_lang, speed=False):
    """Convert text to speech using Google TTS"""
    try:
        # Use the output language for TTS
        tts = gTTS(
            text=text,
            lang=output_lang,
            slow=speed
        )
        
        # Save to temporary file
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.mp3')
        tts.save(temp_file.name)
        
        return temp_file.name
    except Exception as e:
        st.error(f"❌ Error generating speech: {str(e)}")
        return None

def get_download_link(file_path, filename):
    """Generate download link for audio file"""
    with open(file_path, "rb") as f:
        data = f.read()
    b64 = base64.b64encode(data).decode()
    href = f'<a href="data:audio/mp3;base64,{b64}" download="{filename}">📥 Download MP3</a>'
    return href

def main():
    # Page configuration
    st.set_page_config(
        page_title="🎤 EchoVerse - AI Text-to-Speech",
        page_icon="🎤",
        layout="wide"
    )
    
    # Simple clean title
    st.title("🎤 Welcome to EchoVerse")
    st.subheader("AI Text-to-Speech Creator")
    st.markdown("**Type your text, choose a voice, and hear it spoken aloud instantly**")
    
    # Add download option in sidebar
    with st.sidebar:
        st.markdown("---")
        st.subheader("📁 Download Project")
        
        # Create downloadable archive
        import tarfile
        import tempfile
        files_to_include = ['main.py', 'audio_utils.py', 'language_support.py', 'text_processing.py', 'ui_components.py', 'pyproject.toml', 'replit.md']
        
        with tempfile.NamedTemporaryFile(suffix='.tar.gz', delete=False) as tmp:
            with tarfile.open(tmp.name, 'w:gz') as tar:
                for file_name in files_to_include:
                    try:
                        tar.add(file_name)
                    except:
                        pass
            
            with open(tmp.name, 'rb') as f:
                archive_data = f.read()
        
        st.download_button(
            label="Download EchoVerse Files",
            data=archive_data,
            file_name="EchoVerse_Complete.tar.gz",
            mime="application/gzip",
            help="Download all project source files"
        )
    
    # Initialize session state for audio history
    if 'audio_history' not in st.session_state:
        st.session_state.audio_history = []
    # Layout with columns
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.header("📝 Input")
        
        # Language selection for input
        st.subheader("🌍 Input Language")
        input_languages = {
            "🇺🇸 English": "en",
            "🇮🇳 Hindi": "hi", 
            "🇮🇳 Tamil": "ta",
            "🇪🇸 Spanish": "es",
            "🇫🇷 French": "fr",
            "🇩🇪 German": "de",
            "🇯🇵 Japanese": "ja",
            "🇰🇷 Korean": "ko"
        }
        
        input_lang_name = st.selectbox(
            "Select input language:",
            options=list(input_languages.keys()),
            index=0
        )
        input_lang = input_languages[input_lang_name]
        
        # Input format selection
        st.subheader("📄 Input Format")
        input_format = st.radio(
            "Choose how to provide your content:",
            ["Text", "Document", "File Upload", "Audio Recording"],
            horizontal=True
        )
        
        text_input = ""
        
        if input_format == "Text":
            text_input = st.text_area(
                "Enter your text here:",
                height=200,
                placeholder="Type or paste your text here..."
            )
        
        elif input_format == "Document":
            uploaded_file = st.file_uploader(
                "Upload a document",
                type=['pdf', 'docx', 'txt'],
                help="Upload PDF, DOCX, or TXT files"
            )
            
            if uploaded_file is not None:
                text_input = extract_text_from_file(uploaded_file)
                if text_input:
                    st.success(f"✅ Extracted {len(text_input)} characters from {uploaded_file.name}")
                    with st.expander("Preview extracted text"):
                        st.text(text_input[:500] + "..." if len(text_input) > 500 else text_input)
        
        elif input_format == "File Upload":
            uploaded_files = st.file_uploader(
                "Upload files",
                type=['pdf', 'docx', 'txt'],
                accept_multiple_files=True,
                help="Upload multiple PDF, DOCX, or TXT files"
            )
            
            if uploaded_files:
                text_parts = []
                for uploaded_file in uploaded_files:
                    file_text = extract_text_from_file(uploaded_file)
                    if file_text:
                        text_parts.append(f"=== {uploaded_file.name} ===\n{file_text}")
                
                text_input = "\n\n".join(text_parts)
                if text_input:
                    st.success(f"✅ Extracted text from {len(uploaded_files)} files")
                    with st.expander("Preview extracted text"):
                        st.text(text_input[:500] + "..." if len(text_input) > 500 else text_input)
        
        elif input_format == "Audio Recording":
            st.info("🎤 Audio recording feature coming soon! For now, please use text input.")
            text_input = st.text_area(
                "Or enter text directly:",
                height=100,
                placeholder="Type your text here..."
            )
        
        # Tone selection
        st.subheader("🎭 Tone Selection")
        tone_options = ["Neutral", "Suspenseful", "Inspiring"]
        selected_tone = st.selectbox(
            "Choose the tone for your audiobook:",
            options=tone_options,
            help="This will rewrite your text to match the selected tone"
        )
        
        # Output language selection
        st.subheader("🌍 Output Language")
        output_languages = {
            "🇺🇸 English": "en",
            "🇮🇳 Hindi": "hi", 
            "🇮🇳 Tamil": "ta",
            "🇪🇸 Spanish": "es",
            "🇫🇷 French": "fr",
            "🇩🇪 German": "de",
            "🇯🇵 Japanese": "ja",
            "🇰🇷 Korean": "ko"
        }
        
        output_lang_name = st.selectbox(
            "Select output language for speech:",
            options=list(output_languages.keys()),
            index=0
        )
        output_lang = output_languages[output_lang_name]
        
        # Voice selection
        voice_options = {
            "Lisa (Female)": "lisa",
            "Michael (Male)": "michael", 
            "Allison (Female)": "allison"
        }
        
        selected_voice_name = st.selectbox(
            "🎭 Choose Voice:",
            options=list(voice_options.keys())
        )
        selected_voice = voice_options[selected_voice_name]
        
        # Optional settings
        st.subheader("🎚️ Voice Settings")
        
        slow_speech = st.checkbox("Slow Speech", help="Speak more slowly")
        
        # Audio format selection
        audio_format = st.selectbox(
            "🎵 Audio Format:",
            options=["MP3"],
            index=0
        )
        
        # Convert button
        convert_button = st.button("🔊 Convert to Speech", type="primary")
    
    with col2:
        st.header("🎧 Preview & Download")
        
        if convert_button:
            if not text_input.strip():
                st.error("❌ Please enter some text to convert!")
            else:
                with st.spinner("🎭 Rewriting text with selected tone..."):
                    # Apply tone rewriting
                    rewritten_text = rewrite_with_tone(text_input, selected_tone)
                    
                    # Show text comparison
                    if selected_tone != "Neutral":
                        with st.expander("📝 Text Comparison"):
                            col_orig, col_rewritten = st.columns(2)
                            with col_orig:
                                st.subheader("Original Text")
                                st.text(text_input[:300] + "..." if len(text_input) > 300 else text_input)
                            with col_rewritten:
                                st.subheader(f"{selected_tone} Tone")
                                st.text(rewritten_text[:300] + "..." if len(rewritten_text) > 300 else rewritten_text)
                    
                with st.spinner("🎤 Converting to speech..."):
                    audio_file = convert_text_to_speech(
                        rewritten_text, 
                        selected_voice,
                        output_lang,
                        slow_speech
                    )
                    
                    if audio_file:
                        st.success(f"✅ Speech generated successfully with {selected_voice_name}!")
                        
                        # Play audio
                        with open(audio_file, "rb") as audio_bytes:
                            st.audio(audio_bytes.read(), format="audio/mp3")
                        
                        # Download link
                        download_link = get_download_link(audio_file, f"output.mp3")
                        st.markdown(download_link, unsafe_allow_html=True)
                        
                        # Save as output.mp3 in current directory
                        try:
                            with open("output.mp3", "wb") as f:
                                with open(audio_file, "rb") as temp_f:
                                    f.write(temp_f.read())
                            st.info("💾 Audio saved as 'output.mp3' in project directory")
                        except Exception as e:
                            st.warning(f"Could not save to output.mp3: {str(e)}")
                        
                        # Add to history
                        st.session_state.audio_history.append({
                            'text': text_input,
                            'rewritten_text': rewritten_text,
                            'tone': selected_tone,
                            'voice': selected_voice_name,
                            'output_lang': output_lang_name,
                            'file': audio_file
                        })
                        
                        # Cleanup temporary file
                        try:
                            os.unlink(audio_file)
                        except:
                            pass
        
        # History section
        if st.session_state.audio_history:
            st.subheader("📚 Recent Generations")
            for i, item in enumerate(st.session_state.audio_history[-3:]):
                with st.expander(f"Audio {i+1} - {item['tone']} in {item['output_lang']}"):
                    st.markdown(f"**Voice:** {item['voice']}")
                    st.markdown(f"**Tone:** {item['tone']}")
                    st.markdown(f"**Language:** {item['output_lang']}")
                    st.text("Original: " + (item['text'][:100] + "..." if len(item['text']) > 100 else item['text']))
                    if 'rewritten_text' in item:
                        st.text("Rewritten: " + (item['rewritten_text'][:100] + "..." if len(item['rewritten_text']) > 100 else item['rewritten_text']))
                    if os.path.exists(item['file']):
                        with open(item['file'], "rb") as audio_bytes:
                            st.audio(audio_bytes.read(), format="audio/mp3")

    # Footer
    st.markdown("---")
    st.markdown("**Powered by Google Text-to-Speech**")

if __name__ == "__main__":
    main()