import streamlit as st
import PyPDF2
import docx
import io
import tempfile
import os
import re

class TextProcessor:
    def __init__(self):
        # Use rule-based processing for now
        self.text_generator = None
        self.load_model()
    
    @st.cache_resource
    def load_model(_self):
        """Initialize text processing capabilities"""
        try:
            # For now, we'll use rule-based text rewriting
            # This can be upgraded to use IBM Granite model when dependencies are resolved
            _self.text_generator = "rule_based"
            return True
        except Exception as e:
            st.error(f"Error initializing text processor: {str(e)}")
            _self.text_generator = None
            return False
    
    def extract_text_from_file(self, uploaded_file):
        """Extract text from uploaded files (PDF, DOCX, TXT)"""
        try:
            file_type = uploaded_file.type
            text = ""
            
            if file_type == "text/plain":
                # Handle TXT files
                text = uploaded_file.read().decode('utf-8')
            
            elif file_type == "application/pdf":
                # Handle PDF files
                pdf_reader = PyPDF2.PdfReader(uploaded_file)
                for page in pdf_reader.pages:
                    text += page.extract_text() + "\n"
            
            elif file_type in ["application/vnd.openxmlformats-officedocument.wordprocessingml.document"]:
                # Handle DOCX files
                doc = docx.Document(uploaded_file)
                for paragraph in doc.paragraphs:
                    text += paragraph.text + "\n"
            
            else:
                raise ValueError(f"Unsupported file type: {file_type}")
            
            return text.strip()
            
        except Exception as e:
            raise Exception(f"Error extracting text from file: {str(e)}")
    
    def rewrite_with_tone(self, text, tone):
        """Rewrite text with specified tone using rule-based approach"""
        try:
            if self.text_generator is None:
                # Fallback method if model is not available
                return self._fallback_tone_rewrite(text, tone)
            
            # Use enhanced rule-based approach for tone rewriting
            return self._enhanced_tone_rewrite(text, tone)
            
        except Exception as e:
            st.error(f"Error in tone rewriting: {str(e)}")
            return self._fallback_tone_rewrite(text, tone)
    
    def _enhanced_tone_rewrite(self, text, tone):
        """Enhanced rule-based tone rewriting"""
        sentences = re.split(r'[.!?]+', text)
        rewritten_sentences = []
        
        for sentence in sentences:
            if not sentence.strip():
                continue
                
            if tone == "Suspenseful":
                # Add suspenseful elements and pacing
                sentence = sentence.replace(" said ", " whispered ")
                sentence = sentence.replace(" walked ", " crept ")
                sentence = sentence.replace(" looked ", " peered ")
                sentence = sentence.replace(" heard ", " caught the sound of ")
                sentence = sentence.replace(" saw ", " glimpsed ")
                
                # Add suspenseful phrases
                if len(sentence.split()) > 5:
                    sentence = f"Suddenly, {sentence.strip()}"
                sentence += "..."
                
            elif tone == "Inspiring":
                # Add motivational elements
                sentence = sentence.replace(" can't ", " can ")
                sentence = sentence.replace(" couldn't ", " could ")
                sentence = sentence.replace(" impossible ", " challenging yet achievable ")
                sentence = sentence.replace(" difficult ", " rewarding ")
                sentence = sentence.replace(" problem ", " opportunity ")
                sentence = sentence.replace(" failure ", " learning experience ")
                
                # Add inspiring words
                if len(sentence.split()) > 3:
                    inspiring_starters = ["Remarkably, ", "Incredibly, ", "With passion, ", "Courageously, "]
                    import random
                    sentence = random.choice(inspiring_starters) + sentence.strip()
                sentence += "!"
                
            else:  # Neutral
                # Clean and clarify text
                sentence = sentence.replace("...", ".")
                sentence = sentence.replace("!!!", "!")
                sentence = sentence.replace("???", "?")
                sentence = re.sub(r'\s+', ' ', sentence)  # Remove extra spaces
                sentence = sentence.strip() + "."
            
            rewritten_sentences.append(sentence)
        
        return " ".join(rewritten_sentences)
    
    def _fallback_tone_rewrite(self, text, tone):
        """Simple fallback method for tone rewriting"""
        if tone == "Suspenseful":
            modified_text = text.replace(".", "...")
            modified_text = modified_text.replace("said", "whispered")
            modified_text = f"Something mysterious was about to unfold. {modified_text}"
        elif tone == "Inspiring":
            modified_text = text.replace("can't", "can")
            modified_text = modified_text.replace("difficult", "challenging")
            modified_text = f"With determination, {modified_text}!"
        else:  # Neutral
            modified_text = text.replace("...", ".").replace("!!!", "!")
        
        return modified_text
    
    def translate_text(self, text, source_lang, target_lang):
        """Translate text from source language to target language"""
        try:
            from googletrans import Translator
            
            translator = Translator()
            result = translator.translate(text, src=source_lang, dest=target_lang)
            return result.text
            
        except Exception as e:
            st.error(f"Error in translation: {str(e)}")
            return text  # Return original text if translation fails
    
    def chunk_text(self, text, max_chunk_size=1000):
        """Split text into manageable chunks for processing"""
        words = text.split()
        chunks = []
        current_chunk = []
        current_size = 0
        
        for word in words:
            if current_size + len(word) + 1 > max_chunk_size and current_chunk:
                chunks.append(" ".join(current_chunk))
                current_chunk = [word]
                current_size = len(word)
            else:
                current_chunk.append(word)
                current_size += len(word) + 1
        
        if current_chunk:
            chunks.append(" ".join(current_chunk))
        
        return chunks
    
    def process_long_text(self, text, tone):
        """Process long text by chunking and rewriting each chunk"""
        try:
            if len(text.split()) <= 200:
                return self.rewrite_with_tone(text, tone)
            
            chunks = self.chunk_text(text, max_chunk_size=800)
            rewritten_chunks = []
            
            for chunk in chunks:
                rewritten_chunk = self.rewrite_with_tone(chunk, tone)
                rewritten_chunks.append(rewritten_chunk)
            
            return " ".join(rewritten_chunks)
            
        except Exception as e:
            st.error(f"Error processing long text: {str(e)}")
            return text
